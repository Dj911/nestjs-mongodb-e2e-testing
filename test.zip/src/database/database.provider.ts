// import mongoose from "mongoose";

// export const databaseProviders = [
//   {
//     provide: 'DATABASE_CONNECTION',
//     useFactory: (): Promise<typeof mongoose> =>
//       mongoose.connect('mongodb+srv://ethan:supernova@cluster0.aob3a.mongodb.net/test?authSource=admin&replicaSet=atlas-etsuv5-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true'),
//   },
// ];